(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_e3cb289e._.css",
  "static/chunks/_49afcfd1._.js",
  "static/chunks/node_modules_next_be6464f1._.js",
  "static/chunks/node_modules_libphonenumber-js_4fa29673._.js",
  "static/chunks/node_modules_react-phone-number-input_073edee2._.js",
  "static/chunks/node_modules_b8618232._.js"
],
    source: "dynamic"
});
