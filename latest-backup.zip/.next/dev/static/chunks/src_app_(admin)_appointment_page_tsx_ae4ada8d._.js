(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_a094f7fd._.js",
  "static/chunks/node_modules_axios_3c0c0f8e._.js",
  "static/chunks/node_modules_react-icons_io_index_mjs_7f31b177._.js",
  "static/chunks/node_modules_react-icons_md_index_mjs_65e576c2._.js",
  "static/chunks/node_modules_react-icons_hi_index_mjs_c1b692d7._.js",
  "static/chunks/node_modules_react-icons_fi_index_mjs_0a78009b._.js",
  "static/chunks/node_modules_react-icons_lib_844c6c50._.js",
  "static/chunks/node_modules_date-fns_22fae1a5._.js",
  "static/chunks/node_modules_@floating-ui_react_dist_22386cb2._.js",
  "static/chunks/node_modules_react-datepicker_dist_index_es_4982a1c7.js",
  "static/chunks/node_modules_4c43a312._.js",
  "static/chunks/node_modules_react-datepicker_dist_react-datepicker_5992d360.css"
],
    source: "dynamic"
});
