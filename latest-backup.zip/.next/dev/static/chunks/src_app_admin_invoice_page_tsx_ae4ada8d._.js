(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_e7eb3caa._.js",
  "static/chunks/node_modules_axios_3c0c0f8e._.js",
  "static/chunks/node_modules_react-icons_hi_index_mjs_c1b692d7._.js",
  "static/chunks/node_modules_react-icons_io5_index_mjs_9bce8f6c._.js",
  "static/chunks/node_modules_react-icons_fi_index_mjs_0a78009b._.js",
  "static/chunks/node_modules_react-icons_io_index_mjs_7f31b177._.js",
  "static/chunks/node_modules_react-icons_lib_844c6c50._.js",
  "static/chunks/node_modules_next_dist_compiled_buffer_index_9b11b835.js"
],
    source: "dynamic"
});
