module.exports = [
"[project]/.next-internal/server/app/admin/(home)/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_admin_%28home%29_page_actions_a2329c54.js.map