module.exports = [
"[project]/.next-internal/server/app/(admin)/(home)/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_%28home%29_page_actions_a0d4a95c.js.map