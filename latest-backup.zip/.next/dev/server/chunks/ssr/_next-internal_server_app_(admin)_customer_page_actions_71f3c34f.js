module.exports = [
"[project]/.next-internal/server/app/(admin)/customer/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_customer_page_actions_71f3c34f.js.map