module.exports = [
"[project]/.next-internal/server/app/admin/signin/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_admin_signin_page_actions_6f032795.js.map