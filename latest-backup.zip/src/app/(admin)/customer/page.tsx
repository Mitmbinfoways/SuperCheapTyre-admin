"use client";

import { useRouter, useSearchParams, usePathname } from "next/navigation";
import { useState, useEffect, useCallback, useMemo } from "react";
import useDebounce from "@/hooks/useDebounce";
import {
    GetAllAppointments,
    Appointment,
} from "@/services/AppointmentService";
import Pagination from "@/components/ui/Pagination";
import TextField from "@/components/ui/TextField";
import { Toast } from "@/components/ui/Toast";
import Table, { Column } from "@/components/ui/table";
import { EyeIcon } from "@/components/Layouts/sidebar/icons";
import EmptyState from "@/components/EmptyState";
import Skeleton from "@/components/ui/Skeleton";
import CommonDialog from "@/components/ui/Dialogbox";
import Tooltip from "@/components/ui/Tooltip";
import { formatPhoneNumber } from "@/lib/utils";

interface ExtendedAppointment extends Appointment {
    Employee?: string;
    slotDetails: {
        startTime: string;
        endTime: string;
        isBreak: boolean;
    };
    technicianDetails: {
        firstName: string;
        lastName: string;
    };
}

const CustomerPage = () => {
    const router = useRouter();
    const searchParams = useSearchParams();
    const pathname = usePathname();
    const [appointments, setAppointments] = useState<ExtendedAppointment[]>([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const currentPage = Number(searchParams.get("page")) || 1;
    const [totalPages, setTotalPages] = useState(1);
    const [search, setSearch] = useState("");
    const [viewCustomer, setViewCustomer] = useState<ExtendedAppointment | null>(null);
    const itemsPerPage = 10;
    const [totalCustomers, setTotalCustomers] = useState<number>(0);

    const debounceSearch = useDebounce<string>(search, 300);

    const fetchCustomers = useCallback(async () => {
        setLoading(true);
        setError(null);
        try {
            // Fetch all appointments to handle client-side deduplication for unique customers
            const res = await GetAllAppointments({
                search: debounceSearch,
            });

            const uniqueAppointments = res.data.items.filter((item, index, self) => {
                if (!item.email) return true;
                return index === self.findIndex((t) => (
                    t.email.toLowerCase() === item.email.toLowerCase()
                ));
            });

            setTotalCustomers(uniqueAppointments.length);
            setTotalPages(Math.ceil(uniqueAppointments.length / itemsPerPage) || 1);

            // Client-side pagination
            const startIndex = (currentPage - 1) * itemsPerPage;
            const paginatedItems = uniqueAppointments.slice(startIndex, startIndex + itemsPerPage);

            setAppointments(paginatedItems);
        } catch (err: any) {
            const errorMessage =
                err?.response?.data?.message || "Failed to load customers";
            setError(errorMessage);
            Toast({
                message: errorMessage,
                type: "error",
            });
        } finally {
            setLoading(false);
        }
    }, [debounceSearch]);

    const handleViewCustomer = (customer: ExtendedAppointment) => {
        setViewCustomer(customer);
    };

    const handleCloseViewModal = () => {
        setViewCustomer(null);
    };

    const columns: Column<ExtendedAppointment>[] = [
        {
            title: "SR.NO",
            key: "index",
            render: (item, index) => (currentPage - 1) * itemsPerPage + index + 1,
        },
        {
            title: "Customer Name",
            key: "name",
            render: (item) =>
                `${item.firstname ?? ""} ${item.lastname ?? ""}`.trim() || "-",
        },
        {
            title: "Email",
            key: "email",
            render: (item) => <div className="line-clamp-2">{item.email || "-"}</div>,
        },
        {
            title: "Phone",
            key: "phone",
            render: (item) => formatPhoneNumber(item.phone) || "-",
        },
        // {
        //     title: "Appointment Date",
        //     key: "date",
        //     render: (item) =>
        //         item.date ? new Date(item.date).toLocaleDateString() : "-",
        // },
        // {
        //     title: "Time Slot",
        //     key: "slotDetails",
        //     render: (item) =>
        //         item.slotDetails ? (
        //             <span>
        //                 {item.slotDetails.startTime} - {item.slotDetails.endTime}
        //             </span>
        //         ) : (
        //             "-"
        //         ),
        // },
        // {
        //     title: "Notes",
        //     key: "notes",
        //     render: (item) => <div className="max-w-[120px] line-clamp-2">{item.notes || "-"}</div>,
        // },
        {
            title: "Action",
            key: "action",
            align: "right",
            render: (item) => (
                <div className="flex items-center justify-end space-x-3">
                    <Tooltip
                        content="View Details">
                        <button
                            onClick={() => handleViewCustomer(item)}
                            className="cursor-pointer text-gray-600 hover:text-gray-900 dark:text-gray-300 dark:hover:text-white"
                            aria-label="View details"
                        >
                            <EyeIcon className="h-5 w-5" />
                        </button>
                    </Tooltip>
                </div>
            ),
        },
    ];

    useEffect(() => {
        fetchCustomers();
    }, [fetchCustomers]);

    useEffect(() => {
        const current = new URLSearchParams(Array.from(searchParams.entries()));
        if (current.get("page") !== "1") {
            current.set("page", "1");
            router.push(`${pathname}?${current.toString()}`);
        }
    }, [debounceSearch]);

    return (
        <div className="rounded-2xl bg-white p-6 shadow-md dark:bg-gray-900">
            <h1 className="mb-4 text-2xl font-semibold text-primary dark:text-gray-300">
                Customers ({totalCustomers})
            </h1>

            <div className="mb-4 grid grid-cols-1 md:grid-cols-4 gap-4 items-center">
                <div className="flex flex-col gap-1">
                    <TextField
                        type="text"
                        placeholder="Search customers..."
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                    />
                </div>
            </div>

            <div>
                {loading ? (
                    <Skeleton />
                ) : error ? (
                    <div className="py-8 text-center text-red-600 dark:text-red-400">
                        {error}
                    </div>
                ) : appointments.length === 0 ? (
                    <EmptyState message="No customers found." />
                ) : (
                    <>
                        <Table
                            columns={columns}
                            data={appointments}
                            className="dark:divide-gray-700"
                        />
                        <div className="mt-4 flex justify-center">
                            <Pagination
                                currentPage={currentPage}
                                totalPages={totalPages}
                                onPageChange={(page) => {
                                    const current = new URLSearchParams(Array.from(searchParams.entries()));
                                    current.set("page", String(page));
                                    router.push(`${pathname}?${current.toString()}`);
                                }}
                            />
                        </div>
                    </>
                )}
            </div>

            <CommonDialog
                isOpen={!!viewCustomer}
                onClose={handleCloseViewModal}
                title="Customer Details"
                size="lg"
            >
                {viewCustomer && (
                    <div className="space-y-4 text-base">
                        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                            <div>
                                <h3 className="text-base font-medium text-gray-500 dark:text-gray-400">Name</h3>
                                <p className="mt-1 text-base text-gray-900 dark:text-gray-100">
                                    {`${viewCustomer.firstname ?? ""} ${viewCustomer.lastname ?? ""}`.trim() || "-"}
                                </p>
                            </div>
                            <div>
                                <h3 className="text-base font-medium text-gray-500 dark:text-gray-400">Email</h3>
                                <p className="mt-1 text-base text-gray-900 dark:text-gray-100">
                                    {viewCustomer.email || "-"}
                                </p>
                            </div>
                            <div>
                                <h3 className="text-base font-medium text-gray-500 dark:text-gray-400">Phone</h3>
                                <p className="mt-1 text-base text-gray-900 dark:text-gray-100">
                                    {formatPhoneNumber(viewCustomer.phone) || "-"}
                                </p>
                            </div>
                            {/* <div>
                                <h3 className="text-base font-medium text-gray-500 dark:text-gray-400">Appointment Date</h3>
                                <p className="mt-1 text-base text-gray-900 dark:text-gray-100">
                                    {viewCustomer.date ? new Date(viewCustomer.date).toLocaleDateString() : "-"}
                                </p>
                            </div> 
                             <div>
                                <h3 className="text-base font-medium text-gray-500 dark:text-gray-400">Time Slot</h3>
                                <p className="mt-1 text-base text-gray-900 dark:text-gray-100">
                                    {viewCustomer.slotDetails ?
                                        `${viewCustomer.slotDetails.startTime} - ${viewCustomer.slotDetails.endTime}` :
                                        "-"}
                                </p>
                            </div>
                            <div>
                                <h3 className="text-base font-medium text-gray-500 dark:text-gray-400">Status</h3>
                                <p className="mt-1 text-base text-gray-900 dark:text-gray-100">
                                    <Badge label={viewCustomer.status || "-"} color="green" />
                                </p>
                            </div> 
                            <div className="md:col-span-2 max-h-56 overflow-y-auto">
                                <h3 className="text-base font-medium text-gray-500 dark:text-gray-400">Notes</h3>
                                <p className="mt-1 text-base text-gray-900 dark:text-gray-100">
                                    {viewCustomer.notes || "-"}
                                </p>
                            </div> */}
                        </div>
                    </div>
                )}
            </CommonDialog>
        </div>
    );
};

export default CustomerPage;
