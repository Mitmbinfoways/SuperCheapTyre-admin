// Temporary module declaration to satisfy TypeScript resolution in this environment.
// React Redux v9 includes its own types; if your editor resolves them correctly,
// you can remove this file.
declare module 'react-redux';



