"use client";
import React, { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { getOrderById, Order, OrderItem } from "@/services/OrderServices";
import Image from "next/image";
import { Toast } from "@/components/ui/Toast";
import Skeleton from "@/components/ui/Skeleton";
import Button from "@/components/ui/Button";
import Badge from "@/components/ui/Badge";

type LoadingStates = {
  fetchingOrder: boolean;
};

const OrderDetailsPage = ({ params }: { params: Promise<{ id: string }> | { id: string } }) => {
  // Resolve params if it's a Promise
  const resolvedParams = params instanceof Promise ? React.use(params) : params;
  const { id } = resolvedParams;
  const router = useRouter();
  const [order, setOrder] = useState<Order | null>(null);
  const [loadingStates, setLoadingStates] = useState<LoadingStates>({
    fetchingOrder: true,
  });

  const updateLoadingState = (key: keyof LoadingStates, value: boolean) => {
    setLoadingStates((prev) => ({ ...prev, [key]: value }));
  };

  const fetchOrder = async () => {
    updateLoadingState("fetchingOrder", true);
    try {
      const response = await getOrderById(id);
      setOrder(response.data.order);
    } catch (e: any) {
      Toast({
        type: "error",
        message: e?.response?.data?.errorData || "Failed to fetch order details",
      });
      router.push("/admin/orders");
    } finally {
      updateLoadingState("fetchingOrder", false);
    }
  };

  useEffect(() => {
    if (id) {
      fetchOrder();
    }
  }, [id]);

  const renderProductImage = (item: OrderItem) => {
    const imageUrl = item.productDetails.images?.[0]
      ? `${process.env.NEXT_PUBLIC_API_URL}/Product/${item.productDetails.images[0]}`
      : null;

    return imageUrl ? (
      <div className="h-16 w-16 overflow-hidden rounded">
        <Image
          src={imageUrl}
          alt={item.productDetails.name}
          width={64}
          height={64}
          className="h-full w-full object-cover"
          onError={(e) => {
            const target = e.target as HTMLImageElement;
            target.style.display = "none";
            const parent = target.parentElement;
            if (parent) {
              const fallback = document.createElement("div");
              fallback.className =
                "h-full w-full bg-gray-200 flex items-center justify-center dark:bg-gray-700";
              fallback.innerHTML =
                '<span class="text-xs text-gray-500 dark:text-gray-400">No Image</span>';
              parent.appendChild(fallback);
            }
          }}
        />
      </div>
    ) : (
      <div className="flex h-16 w-16 items-center justify-center rounded bg-gray-200 dark:bg-gray-700">
        <span className="text-xs text-gray-500 dark:text-gray-400">
          No Image
        </span>
      </div>
    );
  };

  if (loadingStates.fetchingOrder) {
    return (
      <div className="rounded-2xl bg-white p-4 shadow-md dark:bg-gray-900">
        <Skeleton />
      </div>
    );
  }

  if (!order) {
    return (
      <div className="rounded-2xl bg-white p-4 shadow-md dark:bg-gray-900">
        <div className="text-center py-10">
          <h2 className="text-xl font-semibold text-gray-900 dark:text-gray-100">
            Order not found
          </h2>
          <Button 
            variant="primary" 
            className="mt-4" 
            onClick={() => router.push("/admin/orders")}
          >
            Back to Orders
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="rounded-2xl bg-white p-4 shadow-md dark:bg-gray-900">
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-primary dark:text-gray-300">
          Order Details
        </h1>
        <Button 
          variant="secondary" 
          onClick={() => router.push("/admin/orders")}
        >
          Back to Orders
        </Button>
      </div>

      {/* Order Summary */}
      <div className="mb-8 rounded-lg border border-gray-200 bg-white p-6 dark:border-gray-700 dark:bg-gray-800">
        <h2 className="mb-4 text-xl font-semibold text-gray-900 dark:text-gray-100">
          Order Summary
        </h2>
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-4">
          <div>
            <p className="text-sm text-gray-600 dark:text-gray-300">Order ID</p>
            <p className="font-medium text-gray-900 dark:text-gray-100">
              {order._id}
            </p>
          </div>
          <div>
            <p className="text-sm text-gray-600 dark:text-gray-300">Order Date</p>
            <p className="font-medium text-gray-900 dark:text-gray-100">
              {order.createdAt ? new Date(order.createdAt).toLocaleDateString() : "-"}
            </p>
          </div>
          <div>
            <p className="text-sm text-gray-600 dark:text-gray-300">Total Amount</p>
            <p className="font-medium text-gray-900 dark:text-gray-100">
              AU$ {order.total.toFixed(2)}
            </p>
          </div>
        </div>
      </div>

      {/* Customer Information */}
      <div className="mb-8 rounded-lg border border-gray-200 bg-white p-6 dark:border-gray-700 dark:bg-gray-800">
        <h2 className="mb-4 text-xl font-semibold text-gray-900 dark:text-gray-100">
          Customer Information
        </h2>
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
          <div>
            <p className="text-sm text-gray-600 dark:text-gray-300">Name</p>
            <p className="font-medium text-gray-900 dark:text-gray-100">
              {order.customer.name}
            </p>
          </div>
          <div>
            <p className="text-sm text-gray-600 dark:text-gray-300">Email</p>
            <p className="font-medium text-gray-900 dark:text-gray-100">
              {order.customer.email}
            </p>
          </div>
          <div>
            <p className="text-sm text-gray-600 dark:text-gray-300">Phone</p>
            <p className="font-medium text-gray-900 dark:text-gray-100">
              {order.customer.phone}
            </p>
          </div>
        </div>
      </div>

      {/* Payment Information */}
      <div className="mb-8 rounded-lg border border-gray-200 bg-white p-6 dark:border-gray-700 dark:bg-gray-800">
        <h2 className="mb-4 text-xl font-semibold text-gray-900 dark:text-gray-100">
          Payment Information
        </h2>

        {Array.isArray(order.payment) ? (
          <div className="space-y-4">
            {order.payment.map((payment, index) => (
              <div key={index} className="rounded-md border border-gray-300 p-4 dark:border-gray-600">
                <h3 className="mb-3 font-medium text-gray-800 dark:text-gray-200">
                  Payment #{index + 1}
                </h3>
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 md:grid-cols-4">
                  <div>
                    <p className="text-sm text-gray-600 dark:text-gray-300">Method</p>
                    <p className="font-medium text-gray-900 dark:text-gray-100">
                      {payment?.method || 'Online'}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600 dark:text-gray-300">Status</p>
                    <p className="font-medium text-gray-900 dark:text-gray-100">
                      {payment?.status?.toLowerCase() || '-'}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600 dark:text-gray-300">Amount</p>
                    <p className="font-medium text-gray-900 dark:text-gray-100">
                      {payment?.currency || 'AU$'} {payment?.amount?.toFixed(2) || '-'}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600 dark:text-gray-300">Transaction ID</p>
                    <p className="font-medium text-gray-900 dark:text-gray-100">
                      {payment?.transactionId || "-"}
                    </p>
                  </div>
                  {payment?.paidAt && (
                    <div>
                      <p className="text-sm text-gray-600 dark:text-gray-300">Payment Date</p>
                      <p className="font-medium text-gray-900 dark:text-gray-100">
                        {new Date(payment?.paidAt).toLocaleDateString()}
                      </p>
                    </div>
                  )}
                  {payment?.note && (
                    <div className="md:col-span-4">
                      <p className="text-sm text-gray-600 dark:text-gray-300">Notes</p>
                      <p className="font-medium text-gray-900 dark:text-gray-100">
                        {payment?.note}
                      </p>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        ) : order.payment ? (
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 md:grid-cols-4">
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-300">Payment Method</p>
              <p className="font-medium text-gray-900 dark:text-gray-100">
                {order.payment?.method || '-'}
              </p>
            </div>
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-300">Payment Status</p>
              <p className="font-medium text-gray-900 dark:text-gray-100">
                {order.payment?.status?.toLowerCase() || '-'}
              </p>
            </div>
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-300">Amount</p>
              <p className="font-medium text-gray-900 dark:text-gray-100">
                AU$ {order.total.toFixed(2)}
              </p>
            </div>
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-300">Currency</p>
              <p className="font-medium text-gray-900 dark:text-gray-100">
                {order.payment?.currency || 'AU$'}
              </p>
            </div>
            {(order.payment as any)?.transactionId && (
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-300">Transaction ID</p>
                <p className="font-medium text-gray-900 dark:text-gray-100">
                  {order.payment?.transactionId}
                </p>
              </div>
            )}
            {order.payment?.paidAt && (
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-300">Payment Date</p>
                <p className="font-medium text-gray-900 dark:text-gray-100">
                  {order.payment?.paidAt ? new Date(order.payment?.paidAt).toLocaleDateString() : '-'}
                </p>
              </div>
            )}
            {order.payment?.note && (
              <div className="md:col-span-4">
                <p className="text-sm text-gray-600 dark:text-gray-300">Notes</p>
                <p className="font-medium text-gray-900 dark:text-gray-100">
                  {order.payment?.note}
                </p>
              </div>
            )}
          </div>
        ) : (
          <p className="text-gray-600 dark:text-gray-300">No payment information available</p>
        )}
      </div>

      {/* Products */}
      <div className="rounded-lg border border-gray-200 bg-white p-6 dark:border-gray-700 dark:bg-gray-800">
        <h2 className="mb-4 text-xl font-semibold text-gray-900 dark:text-gray-100">
          Products
        </h2>
        <div className="space-y-4">
          {order.items.map((item) => (
            <div
              key={item._id}
              className="flex items-center gap-4 rounded-lg border bg-white p-4 shadow-sm dark:border-gray-700 dark:bg-gray-700"
            >
              {renderProductImage(item)}
              <div className="flex-1">
                <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100">
                  {item.productDetails.name}
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-300">
                  SKU: {item.productDetails.sku}
                </p>
                <div className="mt-2 flex justify-between text-sm">
                  <span>Quantity: {item.quantity}</span>
                  <span>Price: AU$ {item.productDetails.price.toFixed(2)}</span>
                </div>
                <div className="mt-1 text-right font-medium text-gray-800 dark:text-gray-100">
                  Total: AU${" "}
                  {(item.productDetails.price * item.quantity).toFixed(2)}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default OrderDetailsPage;