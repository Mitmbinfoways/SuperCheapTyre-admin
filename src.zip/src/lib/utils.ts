import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function getProductImageUrl(filename: any) {
  const BASE_URL = process.env.NEXT_PUBLIC_API_URL;
  return `${BASE_URL}/Product/${filename}`;
}

export function getAdminProfile(filename: any) {
  const BASE_URL = process.env.NEXT_PUBLIC_API_URL;
  return `${BASE_URL}/AdminProfile/${filename}`;
}

export function getBrandImageUrl(filename: any) {
  const BASE_URL = process.env.NEXT_PUBLIC_API_URL;
  return `${BASE_URL}/Brand/${filename}`;
}
